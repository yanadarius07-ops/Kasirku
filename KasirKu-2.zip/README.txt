# KasirKu
Aplikasi kasir sederhana berbasis web, tanpa server/database eksternal.

Cara menjalankan:
1. Buka `index.html` di browser.
2. Data produk dan transaksi otomatis tersimpan di localStorage browser.
3. Untuk penggunaan di HP, file ini dapat dibuka melalui browser setelah ditempatkan di hosting/static server.

Fitur:
- Produk, kategori, stok
- Keranjang dan pembayaran
- Kembalian otomatis
- Riwayat/laporan transaksi
- Penyimpanan lokal
